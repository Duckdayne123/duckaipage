// popup.js

const startBtn = document.getElementById("startBtn");
const stopBtn = document.getElementById("stopBtn");
const statusEl = document.getElementById("status");
const speedSelect = document.getElementById("speedSelect"); // NEW

function setStatus(text) {
  statusEl.textContent = text;
}

function sendMessageToActiveTab(message) {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];

      if (!tab || !tab.id) {
        resolve({ ok: false, message: "Không tìm thấy tab active." });
        return;
      }

      chrome.tabs.sendMessage(tab.id, message, (response) => {
        if (chrome.runtime.lastError) {
          resolve({
            ok: false,
            message: "Không gửi được message. Hãy mở tiktok.com rồi reload."
          });
        } else {
          resolve(response || { ok: false, message: "Không nhận được phản hồi." });
        }
      });
    });
  });
}

startBtn.addEventListener("click", async () => {
  setStatus("Đang gửi lệnh Start...");
  startBtn.disabled = true;
  stopBtn.disabled = true;

  const speed = speedSelect?.value || "normal"; // NEW

  const res = await sendMessageToActiveTab({ 
    type: "START_UNLIKE",
    speed 
  });

  if (res?.ok) {
    setStatus(`Đã bắt đầu (${speed}). Xem TikTok để theo dõi.`);
  } else {
    setStatus("❌ Lỗi khi Start: " + (res?.message || "Không rõ."));
  }

  startBtn.disabled = false;
  stopBtn.disabled = false;
});

stopBtn.addEventListener("click", async () => {
  setStatus("Đang gửi lệnh Stop...");
  stopBtn.disabled = true;

  const res = await sendMessageToActiveTab({ type: "STOP_UNLIKE" });

  if (res?.ok) {
    setStatus("⏹ Đã gửi lệnh dừng. Chờ vài giây...");
  } else {
    setStatus("❌ Lỗi khi Stop: " + (res?.message || "Không rõ."));
  }

  stopBtn.disabled = false;
});