// popup.js

const startBtn = document.getElementById("startBtn");
const stopBtn = document.getElementById("stopBtn");
const statusEl = document.getElementById("status");

function setStatus(text) {
  statusEl.textContent = text;
}

function sendMessageToActiveTab(message) {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (!tab || !tab.id) {
        resolve({ ok: false, message: "Không tìm thấy tab active." });
        return;
      }

      chrome.tabs.sendMessage(tab.id, message, (response) => {
        if (chrome.runtime.lastError) {
          resolve({
            ok: false,
            message: "Không gửi được message. Hãy mở tiktok.com và reload."
          });
        } else {
          resolve(response || { ok: false, message: "Không nhận được response." });
        }
      });
    });
  });
}

startBtn.addEventListener("click", async () => {
  setStatus("Đang gửi lệnh Start...");
  startBtn.disabled = true;

  const res = await sendMessageToActiveTab({ type: "START_UNLIKE" });
  if (res?.ok) {
    setStatus("Đã bắt đầu. Xem TikTok để theo dõi overlay.");
  } else {
    setStatus("Lỗi khi Start: " + (res?.message || "Không rõ."));
  }

  startBtn.disabled = false;
});

stopBtn.addEventListener("click", async () => {
  setStatus("Đang gửi lệnh Stop...");
  const res = await sendMessageToActiveTab({ type: "STOP_UNLIKE" });
  if (res?.ok) {
    setStatus("Đã gửi lệnh dừng. Chờ vài giây.");
  } else {
    setStatus("Lỗi khi Stop: " + (res?.message || "Không rõ."));
  }
});
