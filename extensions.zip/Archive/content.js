// content.js

// ===== CONFIG =====
const CONFIG = {
  clickDelayMs: 2000,      // Delay giữa các thao tác (giống setInterval 2000ms trong code gốc)
  maxVideos: 5000          // Giới hạn an toàn
};

// Giống code bạn gửi: dùng [data-e2e="undefined-icon"] để bỏ lưu video
const SELECTORS = {
  // Nút bỏ lưu / remove khỏi Favorites
  savedButton: '[data-e2e="undefined-icon"]',

  // Nút next video (mũi tên sang phải)
  nextButton: '[data-e2e="arrow-right"], button[aria-label*="Next"]'
};

let isRunning = false;
let totalRemoved = 0;

// ===== Helper =====
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function log(...args) {
  console.log("[TikTok-Saved-Cleaner]", ...args);
}

// Overlay hiển thị ở góc màn hình TikTok
function createOverlay() {
  if (document.getElementById("tiktok-saved-cleaner-overlay")) return;

  const box = document.createElement("div");
  box.id = "tiktok-saved-cleaner-overlay";

  Object.assign(box.style, {
    position: "fixed",
    top: "10px",
    right: "10px",
    padding: "10px 14px",
    background: "rgba(0, 0, 0, 0.8)",
    color: "#fff",
    fontFamily: "system-ui, -apple-system, BlinkMacSystemFont, sans-serif",
    fontSize: "13px",
    borderRadius: "8px",
    zIndex: 999999,
    boxShadow: "0 6px 18px rgba(0,0,0,0.5)",
    maxWidth: "260px"
  });

  box.innerHTML = `
    <div style="font-weight:600; margin-bottom:4px;">
      TikTok Saved Auto-Remove
    </div>
    <div id="tiktok-saved-cleaner-status">Đang chờ...</div>
    <div id="tiktok-saved-cleaner-count" style="opacity:0.85; margin-top:3px;"></div>
  `;

  document.body.appendChild(box);
}

function setOverlayStatus(text) {
  const el = document.getElementById("tiktok-saved-cleaner-status");
  if (el) el.textContent = text;
}

function setOverlayCount(text) {
  const el = document.getElementById("tiktok-saved-cleaner-count");
  if (el) el.textContent = text;
}

function removeOverlay() {
  const el = document.getElementById("tiktok-saved-cleaner-overlay");
  if (el) el.remove();
}

// ===== Core logic – BỎ LƯU, KHÔNG PHẢI BỎ TIM =====
async function autoRemoveSavedLoop() {
  createOverlay();
  setOverlayStatus("Đang chạy...");
  setOverlayCount("");

  totalRemoved = 0;

  for (let i = 0; i < CONFIG.maxVideos; i++) {
    if (!isRunning) {
      setOverlayStatus("Đã dừng theo yêu cầu.");
      return;
    }

    // 1. Tìm nút lưu/đã lưu theo selector của bạn
    const savedBtn = document.querySelector(SELECTORS.savedButton);

    if (!savedBtn) {
      log("Không tìm thấy nút lưu/đã lưu (savedButton). Dừng.");
      setOverlayStatus("Không thấy nút lưu nữa, có thể đã hết video được lưu.");
      break;
    }

    // 2. Bấm bỏ lưu
    savedBtn.click();
    totalRemoved++;
    log("Đã bỏ lưu video #" + totalRemoved);
    setOverlayStatus("Đang bỏ lưu khỏi Favorites...");
    setOverlayCount(`Đã bỏ lưu: ${totalRemoved} video`);
    await sleep(CONFIG.clickDelayMs);

    if (!isRunning) {
      setOverlayStatus("Đã dừng theo yêu cầu.");
      return;
    }

    // 3. Next video
    const nextBtn = document.querySelector(SELECTORS.nextButton);

    if (!nextBtn || nextBtn.disabled) {
      log("Không tìm thấy nút Next. Có thể hết danh sách.");
      setOverlayStatus("Không thấy nút next, có thể đã đến cuối danh sách đã lưu.");
      break;
    }

    nextBtn.click();
    log("Next video...");
    setOverlayStatus(`Đang chuyển video tiếp theo (#${totalRemoved + 1})`);
    await sleep(CONFIG.clickDelayMs);
  }

  setOverlayStatus(`Kết thúc. Ước tính đã bỏ lưu ~${totalRemoved} video.`);
  setTimeout(removeOverlay, 6000);
  isRunning = false;
}

// ===== Nhận lệnh từ popup =====
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "START_UNLIKE") {
    if (isRunning) {
      sendResponse({ ok: false, message: "Đang chạy rồi." });
      return;
    }

    isRunning = true;
    log("Bắt đầu auto-remove saved...");
    autoRemoveSavedLoop().catch((err) => {
      log("Lỗi trong loop:", err);
      setOverlayStatus("Lỗi trong quá trình chạy. Check console.");
      isRunning = false;
    });

    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === "STOP_UNLIKE") {
    isRunning = false;
    log("Nhận lệnh dừng.");
    setOverlayStatus("Đang dừng...");
    sendResponse({ ok: true });
    return true;
  }
});
